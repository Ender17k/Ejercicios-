const tableroPuntuacion = {
  Percy: 300,
  Annabeth: 280,
  Grover: 270
};

const nombres = Object.keys(tableroPuntuacion);

console.log(nombres);

// Resultado esperado:
// [ 'Percy', 'Annabeth', 'Grover' ]
