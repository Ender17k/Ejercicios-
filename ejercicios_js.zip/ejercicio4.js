const tableroPuntuacion = {
  Percy: 300,
  Annabeth: 280,
  Grover: 270
};

tableroPuntuacion.Annabeth = 300;

console.log(tableroPuntuacion);

// Resultado esperado:
// { Percy: 300, Annabeth: 300, Grover: 270 }
